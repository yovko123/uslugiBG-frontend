// base path should be / or any folder path where its hosted

// export const base_path ='/react/template/'
export const base_path ='/'
export const img_path ='/'
// export const base_path ='/'
