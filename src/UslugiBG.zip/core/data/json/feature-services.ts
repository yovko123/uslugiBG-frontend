export const featureServicesData =  [
            {
                id: "1",
                service: "Computer Repair",
                serviceStatus: "Active",
                category: "Computer",
                amount: "$80",
                providerName: "John Smith\n                      johnsmith@example.com",
                status: "Active",
                action: ""
            },
            {
                id: "2",
                service: "Car Repair Services",
                serviceStatus: "Active",
                category: "Computer",
                amount: "$80",
                providerName: "Johnny\n                      johnny@example.com",
                status: "Active",
                action: ""
            },
            {
                id: "3",
                service: "Steam Car Wash",
                serviceStatus: "Active",
                category: "Computer",
                amount: "$80",
                providerName: "Robert\n                      robert@example.com",
                status: "Active",
                action: ""
            },
            {
                id: "4",
                service: "House Cleaning",
                serviceStatus: "Active",
                category: "Computer",
                amount: "$80",
                providerName: "Sharonda\n                      sharonda@example.com",
                status: "Active",
                action: ""
            },
            {
                id: "5",
                service: "Computer Repair",
                serviceStatus: "Active",
                category: "Computer",
                amount: "$80",
                providerName: "John Smith\n                      johnsmith@example.com",
                status: "Active",
                action: ""
            },
            {
                id: "6",
                service: "Car Repair Services",
                serviceStatus: "Active",
                category: "Computer",
                amount: "$80",
                providerName: "Johnny\n                      johnny@example.com",
                status: "Active",
                action: ""
            },
            {
                id: "7",
                service: "Steam Car Wash",
                serviceStatus: "Active",
                category: "Computer",
                amount: "$80",
                providerName: "Robert\n                      robert@example.com",
                status: "Active",
                action: ""
            },
            {
                id: "8",
                service: "House Cleaning",
                serviceStatus: "Active",
                category: "Computer",
                amount: "$80",
                providerName: "Sharonda\n                      sharonda@example.com",
                status: "Active",
                action: ""
            }
        ]
   