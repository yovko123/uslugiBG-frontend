export const RegisterReportData = [
  {
    id: '1',
    name: 'John Smith',
    date: '07 Oct 2023',
    status: 'Active',
    badgeClass: 'badge-active completed-active-badge',
  },
  {
    id: '2',
    name: 'Johnny',
    date: '10 Oct 2023',
    status: 'Inactive',
    badgeClass: 'badge-active badge-reject reject-cancel',
  },
  {
    id: '3',
    name: 'Amanda',
    date: '15 Nov 2023',
    status: 'Active',
    badgeClass: 'badge-active completed-active-badge',
  },
  {
    id: '4',
    name: 'James',
    date: '10 Oct 2023',
    status: 'Inactive',
    badgeClass: 'badge-active badge-reject reject-cancel',
  },
];
