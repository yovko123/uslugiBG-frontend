export const pagesData = [
  {
    id: 1,
    pages: 'About Us',
    pagesslug: 'about-us',

    Action: '',
  },
  {
    id: 2,
    pages: 'Home',
    pagesslug: 'home',

    Action: '',
  },
  {
    id: 3,
    pages: 'FAQ',
    pagesslug: 'about-us',

    Action: '',
  },
  {
    id: 4,
    pages: 'Services',
    pagesslug: 'services',

    Action: '',
  },
  {
    id: 5,
    pages: 'Categories',
    pagesslug: 'categories',

    Action: '',
  },
  {
    id: 6,
    pages: 'ContactUs',
    pagesslug: 'contact-us',

    Action: '',
  },
  {
    id: 7,
    pages: 'Privacy Policy',
    pagesslug: 'privacy-policy',

    Action: '',
  },
  {
    id: 8,
    pages: 'Terms Condition',
    pagesslug: 'terms-condition',

    Action: '',
  },
];
