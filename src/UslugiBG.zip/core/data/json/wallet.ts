export const walletData = [
    {
        id: 1,
        img: "assets/admin/img/customer/user-01.jpg",
        userName: "John Smith\n   johnsmith@example.com",
        phone: "+1 843-443-3282",
        balance: "$1000",
        action: "History"
    },
    {
        id: 2,
        img: "assets/admin/img/customer/user-02.jpg",
        userName: "Johnny\n   johnny@example.com",
        phone: "+1 917-409-0861",
        balance: "$800",
        action: "History"
    },
    {
        id: 3,
        img: "assets/admin/img/customer/user-03.jpg",
        userName: "Robert\n  robert@example.com",
        phone: "+1 956-623-2880",
        balance: "$700",
        action: "History"
    },
    {
        id: 4,
        img: "assets/admin/img/customer/user-04.jpg",
        userName: "Sharonda\n   sharonda@example.com",
        phone: "+1 559-741-9672",
        balance: "$600",
        action: "History"
    },
    {
        id: 5,
        img: "assets/admin/img/customer/user-05.jpg",
        userName: "Nicholas\n nicholas@example.com",
        phone: "+1 559-741-9672",
        balance: "$500",
        action: "History"
    }
]