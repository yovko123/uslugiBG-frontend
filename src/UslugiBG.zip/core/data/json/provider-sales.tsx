export const providerSalesData = [
  {
    '#': '1',
    provider: 'John Smith',
    amount: '$38.25',
    date: '07 Oct 2023',
  },
  {
    '#': '2',
    provider: 'Johnny',
    amount: '$20',
    date: '07 Oct 2023',
  },
  {
    '#': '3',
    provider: 'Amanda',
    amount: '$10',
    date: '17 Oct 2023',
  },
  {
    '#': '4',
    provider: 'James',
    amount: '$90',
    date: '17 Oct 2023',
  },
  {
    '#': '5',
    provider: 'John Smith',
    amount: '$38.25',
    date: '07 Oct 2023',
  },
  {
    '#': '6',
    provider: 'Johnny',
    amount: '$20',
    date: '07 Oct 2023',
  },
  {
    '#': '7',
    provider: 'Amanda',
    amount: '$10',
    date: '17 Oct 2023',
  },
  {
    '#': '8',
    provider: 'James',
    amount: '$90',
    date: '17 Oct 2023',
  },
];
