export const adminDashboard2Data = [
  {
    '#': '1',
    providerName: 'Robert',
    email: 'robert@example.com',
    phone: '+1 347-679-8275',
    img: 'assets/admin/img/customer/user-06.jpg',
  },
  {
    '#': '2',
    providerName: 'Sharonda',
    email: 'sharonda@example.com',
    phone: '+1 570-621-248',
    img: 'assets/admin/img/customer/user-09.jpg',
  },
  {
    '#': '3',
    providerName: 'John Smith',
    email: 'johnsmith@example.com',
    phone: '+1 646-957-0004',
    img: 'assets/admin/img/customer/user-01.jpg',
  },
  {
    '#': '4',
    providerName: 'Pricilla',
    email: 'pricilla@example.com',
    phone: '+1 614-915-8101',
    img: 'assets/admin/img/customer/user-05.jpg',
  },
  {
    '#': '5',
    providerName: 'James',
    email: 'james@example.com',
    phone: '+1 918-543-3702',
    img: 'assets/admin/img/customer/user-09.jpg',
  },
];
