export const dashboard = [
  {
    tittle: 'Home',
    showAsTab: false,
    separateRoute: false,
  },
];
