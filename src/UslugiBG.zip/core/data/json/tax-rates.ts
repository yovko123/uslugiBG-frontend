export const taxRatesData = [
    {
        id: 1,
        taxName: "Casual Customs",
        taxPercentage: "0.00%",
        action: " \n   Edit\n Delete"
    },
    {
        id: 2,
        taxName: "Your Tax Assistance",
        taxPercentage: "2.00%",
        action: " \n   Edit\n Delete"
    },
    {
        id: 3,
        taxName: "Essential Expenses",
        taxPercentage: "7.25%",
        action: " \n   Edit\n Delete"
    },
    {
        id: 4,
        taxName: "Taxing Co",
        taxPercentage: "4.50%",
        action: " \n   Edit\n Delete"
    },
    {
        id: 5,
        taxName: "Afflict Tax Payers",
        taxPercentage: "0.00%",
        action: " \n   Edit\n Delete"
    },
    {
        id: 6,
        taxName: "Financial Cub",
        taxPercentage: "1.00%",
        action: " \n   Edit\n Delete"
    },
    {
        id: 7,
        taxName: "The Pocketbook",
        taxPercentage: "2.55%",
        action: " \n   Edit\n Delete"
    },
    {
        id: 8,
        taxName: "Tax Deduction Collective",
        taxPercentage: "0.00%",
        action: " \n   Edit\n Delete"
    }
]
