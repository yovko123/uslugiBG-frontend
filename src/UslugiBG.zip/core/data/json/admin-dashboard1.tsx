export const adminDashboard1Data = [
  {
    '#': '1',
    service: 'Computer Repair',
    category: 'Computer',
    amount: '$80',
    img: 'assets/admin/img/services/service-03.jpg',
  },
  {
    '#': '2',
    service: 'Car Repair Services',
    category: 'Automobile',
    amount: '$50',
    img: 'assets/admin/img/services/service-02.jpg',
  },
  {
    '#': '3',
    service: 'Car Wash',
    category: 'Automobile',
    amount: '$14',
    img: 'assets/admin/img/services/service-04.jpg',
  },
  {
    '#': '4',
    service: 'House Cleaning',
    category: 'Cleaning',
    amount: '$100',
    img: 'assets/admin/img/services/service-09.jpg',
  },
  {
    '#': '5',
    service: 'Interior',
    category: 'Cleaning',
    amount: '$50',
    img: 'assets/admin/img/services/service-10.jpg',
  },
];
