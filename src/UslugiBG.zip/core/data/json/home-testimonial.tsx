export const homeTestimonial = [
  {
    id: 1,
    Title: 'Quality of work was excellent',
    Content:
      '“ I had a great experience with ABC Electrical on the Services. The electrician arrived on time!!!“',
    Image: 'avatar-14.jpg',
    Name: 'Robert Anderson',
    Post: '2 Days Ago',
  },
  {
    id: 2,
    Title: 'Green Cleaning',
    Content:
      '“ I love that they use eco-friendly products without compromising on cleanliness with care.“',
    Image: 'avatar-15.jpg',
    Name: 'Delois Coffin',
    Post: '3 Days Ago',
  },
  {
    id: 3,
    Title: 'Luxury Car Cleaning',
    Content:
      '“Exceptional care for my luxury vehicle. The team treated my car with precision and care.“',
    Image: 'avatar-13.jpg',
    Name: 'Matthew Hicks',
    Post: '5 Days Ago',
  },
  {
    id: 4,
    Title: 'Quick and reliable',
    Content:
      '“They fixed my issue in no time and got everything running smoothly again! Good work“',
    Image: 'avatar-12.jpg',
    Name: 'Daniel Davis',
    Post: '7 Days Ago',
  },
];
