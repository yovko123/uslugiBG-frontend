export const smstemplate = [
  {
    ReferenceID: 1,
    smsTitle: 'Registration Confirmation',
    Date: '28 Sep 2023 16:43:20',
    Action: ' ',
  },
  {
    ReferenceID: 2,
    smsTitle: 'User Booked Confirmation',
    Date: '23 Sep 2023 10:43:20',
    Action: ' ',
  },
  {
    ReferenceID: 3,
    smsTitle: 'Booking Status',
    Date: '23 Sep 2023 10:43:20',
    Action: ' ',
  },
  {
    ReferenceID: 4,
    smsTitle: 'Admin Refund',
    Date: '23 Sep 2023 10:43:20',
    Action: ' ',
  },
  {
    ReferenceID: 5,
    smsTitle: 'Admin Refund',
    Date: '28 Sep 2023 16:43:20',
    Action: ' ',
  },
  {
    ReferenceID: 6,
    smsTitle: 'Service Approval',
    Date: '28 Sep 2023 16:43:20',
    Action: ' ',
  },
  {
    ReferenceID: 7,
    smsTitle: 'Subscription Expires',
    Date: '28 Sep 2023 16:43:20',
    Action: ' ',
  },
  {
    ReferenceID: 8,
    smsTitle: 'Provider Booked Confirmation',
    Date: '23 Sep 2023 10:43:20',
    Action: ' ',
  },
];
