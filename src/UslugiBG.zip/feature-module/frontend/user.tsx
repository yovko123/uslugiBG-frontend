import React from 'react';


const Admin = () => {
  return (
    <div className=''>
    </div>
  );
};

export default Admin;
