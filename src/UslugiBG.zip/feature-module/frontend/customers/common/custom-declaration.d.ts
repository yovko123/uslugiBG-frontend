declare module 'react-awesome-stars-rating';
 